package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;


public class InformacijeFrag extends Fragment {
    private TextView nazivKviza;
    private TextView brojTacnihPitanja;
    private TextView brojPreostalihPitanja;
    private TextView procenatTacnih;

    private OnButtonClick onButtonClick;
    private Button zavrsiKvizBtn;

    private Kviz kviz;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.informacije_frag, container, false);
        nazivKviza = view.findViewById(R.id.infNazivKviza);
        brojTacnihPitanja = view.findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihPitanja = view.findViewById(R.id.infBrojPreostalihPitanja);
        procenatTacnih = view.findViewById(R.id.infProcenatTacni);
        zavrsiKvizBtn = view.findViewById(R.id.btnKraj);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        kviz = (Kviz) getArguments().getSerializable("kviz");
        if(kviz != null){
            Integer odgovorenaPitanja = getArguments().getInt("odgovorenaPitanja");
            Integer brojTacnoOdgovorenih = getArguments().getInt("brojTacnoOdgovorenih");
            nazivKviza.setText(kviz.getNaziv());
            brojTacnihPitanja.setText(brojTacnoOdgovorenih + "");
            brojPreostalihPitanja.setText(kviz.getPitanja().size() - odgovorenaPitanja < 1 ? "0" : (kviz.getPitanja().size() - odgovorenaPitanja - 1) + "");
            procenatTacnih.setText(odgovorenaPitanja == 0 ? "0.0%" : String.format("%.1f",(((double)brojTacnoOdgovorenih)/odgovorenaPitanja*100)) + "%");
        }


        onButtonClick = (OnButtonClick) getActivity();
        zavrsiKvizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onButtonClick.onClicked();
            }
        });
    }


    public interface OnButtonClick {
        void onClicked();
    }

}
