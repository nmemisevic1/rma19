package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.adapteri.kategorija.KategorijaAdapterLista;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;


public class ListaFrag extends Fragment {
    private ArrayList<Kategorija> kategorije;
    private KategorijaAdapterLista kategorijaAdapter;
    private ListView listaKategorija;
    private OnItemClick onItemClick;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.lista_frag, container, false);
        listaKategorija = view.findViewById(R.id.listaKategorija);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        kategorije = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");

        kategorijaAdapter = new KategorijaAdapterLista(getContext(), R.layout.element_liste_kategorije, kategorije);
        listaKategorija.setAdapter(kategorijaAdapter);

        onItemClick = (OnItemClick) getActivity();

        listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onItemClick.onListItemClicked(kategorije.get(position).getIdBaza());
            }
        });

    }

    public interface OnItemClick {
        void onListItemClicked(String idBaza);
    }
}
