package ba.unsa.etf.rma.adapteri.kategorija;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;

public class KategorijaAdapterLista extends ArrayAdapter<Kategorija> {
    ArrayList<Kategorija> kategorije = new ArrayList<>();


    public KategorijaAdapterLista(Context context, int resource, ArrayList<Kategorija> kategorije) {
        super(context, resource, kategorije);
        this.kategorije = kategorije;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View novi = layoutInflater.inflate(R.layout.element_liste_kategorije, null);

        TextView textView = novi.findViewById(R.id.listaNazivKategorije);
        textView.setText(kategorije.get(position).getNaziv());
        return novi;
    }

}
