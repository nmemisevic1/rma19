package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.kviz.KvizAdapterGrid;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class DetailFrag extends Fragment {
    private GridView gridKvizovi;
    private ArrayList<Kviz> kvizovi = new ArrayList<>();
    private KvizAdapterGrid kvizAdapter;
    private ArrayList<Kategorija> kategorije;

    private onItemClick onItemClick;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detail_frag, container, false);
        gridKvizovi = view.findViewById(R.id.gridKvizovi);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        kategorije = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");
        kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("kvizovi");
        kvizAdapter = new KvizAdapterGrid(getContext(), R.layout.element_grid, kvizovi);
        gridKvizovi.setAdapter(kvizAdapter);

        onItemClick = (DetailFrag.onItemClick) getActivity();

        gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onItemClick.onGridItemClicked(kvizovi.get(position).getId(), kvizovi);
            }
        });

        gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                onItemClick.onLongGridItemClicked(kvizovi.get(position).getId());
                return true;
            }
        });

    }

    public interface onItemClick{
        void onGridItemClicked(String id, ArrayList<Kviz> kvizovi);
        void onLongGridItemClicked(String id);
    }
}
