package ba.unsa.etf.rma.Klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filterable;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class MyArrayAdapterKategorija extends BaseAdapter {
        ArrayList<Kategorija> kategorije;
        Context context;
        public MyArrayAdapterKategorija(Context context, ArrayList<Kategorija> arrayList) {
            this.kategorije =arrayList;
            this.context=context;
        }
        @Override
        public int getCount() {
            return kategorije.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            Kategorija kategorija = kategorije.get(position);
            if (convertView == null) {
                LayoutInflater layoutInflater = LayoutInflater.from(context);
                convertView=layoutInflater.inflate(R.layout.text_view_item, null);

            }

            TextView imeKviza = convertView.findViewById(R.id.naziv);
            imeKviza.setText(kategorija.getNaziv());

            return convertView;
        }
}
