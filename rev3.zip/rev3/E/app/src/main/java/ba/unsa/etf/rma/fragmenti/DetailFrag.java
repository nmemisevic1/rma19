package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.KvizAdapter;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.async.NabaviKvizovePoKategorijiTask;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class DetailFrag extends Fragment implements NabaviKvizovePoKategorijiTask.OnKvizoviSearchDone {

    public static ArrayList<Kviz> trenutniKvizovi;
    private KvizAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detail_fragment, container, false);

        GridView grid = (GridView)view.findViewById(R.id.gridKvizovi);

        trenutniKvizovi = new ArrayList<>();

        adapter = new KvizAdapter(getActivity(), R.layout.element_grida, trenutniKvizovi);
        grid.setAdapter(adapter);

        sort(getArguments().getInt("pozicija"));
        adapter.notifyDataSetChanged();

        grid.setLongClickable(true);
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                if (position != trenutniKvizovi.size() - 1) {
                    myIntent.putExtra("nazivKviza", trenutniKvizovi.get(position).getNaziv());
                    myIntent.putExtra("kategorijaIndex", getCatPosition(trenutniKvizovi.get(position).getKategorija().getNaziv()) - 1);
                    myIntent.putExtra("pozicija", position);
                    myIntent.putExtra("oldNaziv", trenutniKvizovi.get(position).getNaziv());
                    //myIntent.putParcelableArrayListExtra("pitanja", tempListaPitanja);
                    KvizoviAkt.tempListaPitanja = trenutniKvizovi.get(position).getPitanja();
                    myIntent.putExtra("edit", true);
                } else {
                    myIntent.putExtra("edit", false);
                }
                ArrayList<String> kvizoviImena = new ArrayList<>();
                for (Kviz k : KvizoviAkt.kvizovi)
                    kvizoviImena.add(k.getNaziv());
                myIntent.putExtra("kvizoviUzetaImena", kvizoviImena);
                startActivity(myIntent);
                return true;
            }
        });

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (trenutniKvizovi.get(position).getNaziv() != "Dodaj Kviz") {
                    Intent myIntent = new Intent(getActivity(), IgrajKvizAkt.class);
                    myIntent.putExtra("nazivKviza", trenutniKvizovi.get(position).getNaziv());
                    myIntent.putExtra("kategorijaIndex", getCatPosition(trenutniKvizovi.get(position).getKategorija().getNaziv()) - 1);
                    IgrajKvizAkt.pitanja = trenutniKvizovi.get(position).getPitanja();
                    if(IgrajKvizAkt.pitanja.size() != 0)
                        if (IgrajKvizAkt.pitanja.get(IgrajKvizAkt.pitanja.size() - 1).getNaziv().equals("Dodaj Pitanje"))
                            IgrajKvizAkt.pitanja.remove(IgrajKvizAkt.pitanja.size() - 1);
                    startActivity(myIntent);
                } else {
                    Intent myIntent = new Intent(getActivity(), DodajKvizAkt.class);
                    if (position != trenutniKvizovi.size() - 1) {
                        myIntent.putExtra("nazivKviza", trenutniKvizovi.get(position).getNaziv());
                        myIntent.putExtra("kategorijaIndex", getCatPosition(trenutniKvizovi.get(position).getKategorija().getNaziv()) - 1);
                        //myIntent.putParcelableArrayListExtra("pitanja", tempListaPitanja);
                        KvizoviAkt.tempListaPitanja = trenutniKvizovi.get(position).getPitanja();
                        myIntent.putExtra("pozicija", KvizoviAkt.kvizovi.indexOf(trenutniKvizovi.get(position)));
                        myIntent.putExtra("edit", true);
                    } else {
                        myIntent.putExtra("edit", false);
                    }
                    ArrayList<String> kvizoviImena = new ArrayList<>();
                    for (Kviz k : KvizoviAkt.kvizovi)
                        kvizoviImena.add(k.getNaziv());
                    myIntent.putExtra("kvizoviUzetaImena", kvizoviImena);
                    startActivity(myIntent);
                }
            }
        });

        return view;
    }

    private void updateQuizList(int position, ArrayList<Kviz> kvizoviArg){
        trenutniKvizovi.clear();
        if(position == 0) {
            trenutniKvizovi.addAll(KvizoviAkt.kvizovi);
        }
        else{
            trenutniKvizovi.addAll(kvizoviArg);
        }
        trenutniKvizovi.add(new Kviz("Dodaj Kviz",null, new Kategorija("DodajKviz", "temp")));
        adapter.notifyDataSetChanged();
    }

    private int getCatPosition(String name){
        for(int i = 0; i < KvizoviAkt.kategorije.size(); i++)
            if(KvizoviAkt.kategorije.get(i).getNaziv().equals(name)){
                return i;
            }
        return -1;
    }

    public static boolean doesCategoryExist(String name) {
        for(Kategorija kat : KvizoviAkt.kategorije){
            if(kat.getNaziv().equals(name))
                return true;
        }
        return false;
    }

    public static boolean doesQuizExist(String name){
        for(Kviz k : KvizoviAkt.kvizovi){
            if(k.getNaziv().equals(name))
                return true;
        }
        return false;
    }

    public void update(){
        adapter.notifyDataSetChanged();
        updateQuizList(0, null);
    }

    public void sort(int i){
        if(i == 0)
            update();
        else
            new NabaviKvizovePoKategorijiTask((NabaviKvizovePoKategorijiTask.OnKvizoviSearchDone)DetailFrag.this).execute(KvizoviAkt.kategorije.get(i).getNaziv());
    }

    @Override
    public void onDone4(ArrayList<Kviz> kvizList) {
        updateQuizList(1, kvizList);
    }
}
