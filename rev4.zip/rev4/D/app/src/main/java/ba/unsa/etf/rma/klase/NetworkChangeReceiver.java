package ba.unsa.etf.rma.klase;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;

public class NetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, final Intent intent) {

        int status = NetworkUtil.getConnectivityStatusString(context);
        Log.e("KONEKCIJA", "Nema konekcije");
        if ("android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction())) {
            int konektovan=1;
            if (status == NetworkUtil.NETWORK_STATUS_NOT_CONNECTED) {
                konektovan =0;
                Intent mIntent = new Intent(context, KvizoviAkt.class);
                mIntent.putExtra("internet", konektovan);
                context.startActivity(mIntent);
            } else {
                konektovan = 1;
                Intent mIntent = new Intent(context, KvizoviAkt.class);
                mIntent.putExtra("internet", konektovan);
                context.startActivity(mIntent);
            }
        }
    }
}