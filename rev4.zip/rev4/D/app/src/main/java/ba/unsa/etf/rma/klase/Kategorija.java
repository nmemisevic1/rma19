package ba.unsa.etf.rma.klase;

import java.io.Serializable;

public class Kategorija implements Serializable {
    private String naziv;
    private String id;
    private static int ID=1;
    public int getIndikator() {
        return indikator;
    }

    public void setIndikator(int indikator) {
        this.indikator = indikator;
    }

    private int indikator=0;
    public Kategorija(String naziv, int kategorija) {
        this.naziv = naziv;
        this.slikaKategorije=kategorija;
        this.id="kat_" + ID++;
    }

    public int getSlikaKategorije() {
        return slikaKategorije;
    }

    public void setSlikaKategorije(int slikaKategorije) {
        this.slikaKategorije = slikaKategorije;
    }

    private int slikaKategorije;

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
       return naziv;
    }
}
