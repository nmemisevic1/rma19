package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DataWrapper;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    boolean postavljenTacan=false;
    String tacan="";
    View row;

    public class DodajPitanjeTask extends AsyncTask<String,Void, Void> {
        String jsonString="";
        public void pripremiJSONPitanje(Pitanje p)
        {
            int tacanO=0;
            for (int i = 0; i < p.getOdgovori().size(); i++)
                if (p.getOdgovori().get(i).toString().equals(p.getTacan())) tacanO=i;

            jsonString ="{ \"fields\": { \"indexTacnog\": {\"integerValue\":\"";
            jsonString += tacanO;
            jsonString += "\"},";
            jsonString +=  "\"naziv\": {\"stringValue\":\"";
            jsonString += p.getNaziv();
            jsonString += "\"},";
            jsonString +=  "\"odgovori\": {\"arrayValue\":{\"values\":[";
            for (int i = 0; i < p.getOdgovori().size(); i++) {
                jsonString += "{\"stringValue\":\"";
                jsonString += p.getOdgovori().get(i);
                jsonString += "\"}";
                if (i!=p.getOdgovori().size()-1) jsonString += ",";
            }
            jsonString += "]}}}}";
        }
        @Override
        protected Void doInBackground(String... strings)
        {
            GoogleCredential credentials;
            try {
                InputStream secretStream = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(secretStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url ="https://firestore.googleapis.com/v1beta1/projects/spirala3-rma-17324-241419/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url+ URLEncoder.encode(TOKEN, "utf-8"));
                HttpURLConnection conn = (HttpURLConnection)urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = jsonString;//"{ \"fields\": { \"idKategorije\": {\"stringValue\":\"0\"}}}"; //treba promijeniti ID
                try(OutputStream os = conn.getOutputStream()){
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine=null;
                    while ((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }

            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    public void azurirajBoju(ListView l)
    {
        int pozicijaDodavanja = l.getLastVisiblePosition();
        l.getChildAt(pozicijaDodavanja).setBackgroundColor(Color.GREEN);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        //kupi iz prethodne aktivnosti
        DataWrapper dw = (DataWrapper) getIntent().getSerializableExtra("data");
        final ArrayList<Kviz> kvizovi = dw.getKvizovi();
        final ArrayList<Kategorija> kategorije = dw.getKategorije();
        final ArrayList<Pitanje> pitanja = dw.getPitanja();
        final int originalnaPozicija = dw.getLokacija();
        final ArrayList<String> odgovori = new ArrayList<String>();
        final ListView listaOdgovora = (ListView) findViewById(R.id.lvOdgovori);
        final ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, odgovori);

        listaOdgovora.setAdapter(adapter2);
        final Button dodajO = (Button) findViewById(R.id.btnDodajOdgovor);
        dodajO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText odgovor = findViewById(R.id.etOdgovor);
                String tekstOdgovora = odgovor.getText().toString();
                //Drawable originalnaBoja = odgovor.getBackground();
                if (tekstOdgovora.length()!=0)
                {
                    odgovor.setBackgroundColor(android.R.color.transparent);
                    //treba dodati na adapter liste kasnije
                    odgovori.add(tekstOdgovora);
                    adapter2.notifyDataSetChanged();
                }
                //ne smijemo dozvoliti prazan odgovor pa bojimo pozadinu elementa etOdgovor u crveno
                else odgovor.setBackgroundColor(Color.RED);

            }
        });
        //dodajtacan
        final Button dodajT = (Button) findViewById(R.id.btnDodajTacan);
        dodajT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText odgovor = findViewById(R.id.etOdgovor);
                String tekstOdgovora = odgovor.getText().toString();
                //Drawable originalnaBoja = odgovor.getBackground();
                if (tekstOdgovora.length()!=0 && !postavljenTacan)
                {
                    odgovor.setBackgroundColor(android.R.color.transparent);
                    odgovori.add(tekstOdgovora);
                    postavljenTacan=true;
                    tacan=tekstOdgovora;
                    adapter2.notifyDataSetChanged();
                    //nakon azuriranja liste treba dati zelenu boju
                    listaOdgovora.post( new Runnable() {
                        @Override
                        public void run()
                        {
                            azurirajBoju(listaOdgovora);
                        }
                    });
                }
                //ne smijemo dozvoliti prazan odgovor pa bojimo pozadinu elementa etOdgovor u crveno
                else if (tekstOdgovora.length()==0)
                    odgovor.setBackgroundColor(Color.RED);
                //ako vec imamo tacan onemogucavamo dugme za dodavanje novog tacnog odgovora
                if (postavljenTacan) dodajT.setEnabled(false);

            }
        });
        //na kraju ide finaliziranje pitanja i povratak uz prenos istog
        final Button spremi = (Button) findViewById(R.id.btnDodajPitanje);
        spremi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText naziv = findViewById(R.id.etNaziv);
                String tekstNaziva = naziv.getText().toString();
                //Drawable originalnaBoja = odgovor.getBackground();
                boolean postojiIstiNaziv=false;
                //ne smije biti isti naziv pitanja u kvizu
                for (int i = 0; i < pitanja.size(); i++)
                    if (pitanja.get(i).getNaziv().toString().equals(tekstNaziva)) postojiIstiNaziv=true;
                if (tekstNaziva.length()!=0 && postavljenTacan && !postojiIstiNaziv)
                {
                    Pitanje pitanjce=new Pitanje(tekstNaziva,tekstNaziva,odgovori, tacan, R.drawable.ic_launcher_background);
                    //radimo posao prenosa svega
                    pitanja.add(0, pitanjce);
                   if (originalnaPozicija!=-1) //PATCH
                    kvizovi.get(originalnaPozicija).setPitanja(pitanja);
                   //FLAG
                       DodajPitanjeTask dpt = new DodajPitanjeTask();
                       dpt.pripremiJSONPitanje(pitanjce);
                       dpt.execute("proba");

                   //FLAG
                    Intent dodavanjePitanja = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                    dodavanjePitanja.putExtra("data", new DataWrapper(kvizovi, kategorije, pitanja, originalnaPozicija));
                    startActivity(dodavanjePitanja);
                }
                //ne smijemo dozvoliti prazan odgovor pa bojimo pozadinu elementa etOdgovor u crveno
                else naziv.setBackgroundColor(Color.RED);

            }
        });

        listaOdgovora.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterac, View view, int position, long arg) {
                //ako se nakon postavljanja obrise tacan odgovor treba resetovati dugme
                    if (odgovori.get(position).toString().equals(tacan))
                    {
                        postavljenTacan=false;
                        dodajT.setEnabled(true);
                        tacan="";
                    }
                        odgovori.remove(position);
                    adapter2.notifyDataSetChanged();
            }
        });
    }
}
