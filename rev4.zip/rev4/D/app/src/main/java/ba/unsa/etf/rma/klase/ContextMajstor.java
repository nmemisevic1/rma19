package ba.unsa.etf.rma.klase;

import android.app.Application;
import android.content.Context;

public class ContextMajstor extends Application {
    public Context getContextApp() {
        return contextApp;
    }

    public void setContextApp(Context contextApp) {
        this.contextApp = contextApp;
    }

    public Context contextApp = getBaseContext();
    @Override
    public void onCreate() {

        super.onCreate();

    }
}
