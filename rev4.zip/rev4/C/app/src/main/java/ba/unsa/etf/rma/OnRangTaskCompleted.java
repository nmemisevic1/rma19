package ba.unsa.etf.rma;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Rang;

public interface OnRangTaskCompleted {
    void onRangTaskCompleted(ArrayList<Rang> rangLista);
}
