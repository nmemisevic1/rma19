package ba.unsa.etf.rma.klase;

public class NeispravnaDatotekaException extends Exception {
    public NeispravnaDatotekaException(){
        super();
    }

    public NeispravnaDatotekaException(String s){
        super(s);
    }
}
